<html> 
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	
	<body>

        <form action="trav.php" method = "get" >
           
          <label for="name">Enter the product to be searched</label>
          <input type="text" name="keyword">

          <input type="Submit" value="submit">

        </form>      

    </body>
</html>
